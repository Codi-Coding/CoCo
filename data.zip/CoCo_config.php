<?php

define('IMAGE_KEY', 'CoCo_Fitting');
// define('DeepLearning_Server', 'http://121.140.133.98:5000');
define('DeepLearning_Server', 'http://121.140.208.20:10008');
define('Fitting_table', 'CoCo_fitting_cart');
define('Cody_table', 'CoCo_cody');


?>